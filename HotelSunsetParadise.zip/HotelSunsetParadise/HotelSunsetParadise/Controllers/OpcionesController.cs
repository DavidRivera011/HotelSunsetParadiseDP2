﻿using Microsoft.AspNetCore.Mvc;

namespace HotelSunsetParadise.Controllers
{
    public class OpcionesController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
